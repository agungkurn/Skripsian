models_21: the "original" first 21 files
models_26: + vega
models_31: + vega + adi
models_36: + vega + adi + reifza
models_41: + vega + adi + reifza + reifza (headset)